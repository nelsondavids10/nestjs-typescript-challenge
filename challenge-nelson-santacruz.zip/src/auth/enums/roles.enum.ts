/* eslint-disable prettier/prettier */
export enum Role {
    Admin = 'admin',
    Agent = 'agent',
    Customer = 'customer',
    Guest = 'guest',
}